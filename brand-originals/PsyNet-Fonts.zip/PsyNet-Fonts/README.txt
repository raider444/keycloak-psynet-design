PsyNet Fonts — version 0.1

PsyNet Sans: geometric alphabet for regular text.
PsyNet Circuit: display alphabet with contact rings.

Install either TTF or OTF, not both formats of the same family.
Latin, Cyrillic and Greek, digits, punctuation and combining accents are included.
Primary alphabet glyphs are redrawn; extended characters and accent positioning are derived from DejaVu Sans.
This is a first design release; no bold or italic styles or custom kerning yet.
Circuit is intended for headings, not small body text.

License: see LICENSE.txt.
