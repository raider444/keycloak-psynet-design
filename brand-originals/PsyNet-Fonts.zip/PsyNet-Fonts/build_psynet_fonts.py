from pathlib import Path
import sys,math,copy,zipfile,json
P=Path(__file__).parent;sys.path.insert(0,str(P/'font_deps'))
from svgpathtools import parse_path
from shapely.geometry import LineString,Point
from shapely.ops import unary_union
from shapely.geometry.polygon import orient
from fontTools.ttLib import TTFont
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.t2CharStringPen import T2CharStringPen
from fontTools.fontBuilder import FontBuilder
from PIL import Image,ImageDraw,ImageFont
OUT=P/'PsyNet-Fonts';OUT.mkdir(exist_ok=True)
recipes={}
def add(chars,d,w=620):
    for c in chars:recipes[c]=(d,w)
add('AΑА','M60 0L310 700L560 0 M145 240H475')
add('BΒВ','M70 0V700H365C590 700 590 355 365 355H70 M365 355C625 355 625 0 365 0H70')
add('CС','M550 595C475 750 70 750 70 380V320C70 -50 475 -50 550 105')
add('D','M70 0V700H305C650 700 650 0 305 0H70')
add('EΕЕ','M550 0H70V700H550 M70 350H455')
add('F','M70 0V700H550 M70 350H455')
add('G','M550 595C475 750 70 750 70 380V320C70 -50 550 -50 550 210V330H335')
add('HΗН','M70 0V700 M550 0V700 M70 350H550')
add('IΙІ','M170 0V700',340)
add('JЈ','M480 700V155C480 -55 70 -55 70 155',560)
add('KΚК','M70 0V700 M540 700L70 300 M230 430L560 0')
add('L','M70 700V0H550')
add('MΜМ','M70 0V700L380 275L690 700V0',760)
add('NΝ','M70 0V700L550 0V700')
add('OΟО','M310 700C90 700 65 570 65 350C65 130 90 0 310 0C530 0 555 130 555 350C555 570 530 700 310 700Z')
add('PΡР','M70 0V700H360C625 700 625 350 360 350H70')
add('Q','M310 700C90 700 65 570 65 350C65 130 90 0 310 0C530 0 555 130 555 350C555 570 530 700 310 700Z M355 175L600 -60',660)
add('R','M70 0V700H360C625 700 625 350 360 350H70 M330 350L570 0')
add('SЅ','M550 635C475 750 70 750 70 535C70 290 550 430 550 170C550 -65 140 -65 70 65')
add('TΤТ','M50 700H570 M310 700V0')
add('U','M70 700V180C70 -65 550 -65 550 180V700')
add('V','M60 700L310 0L560 700')
add('W','M50 700L210 0L380 500L550 0L710 700',760)
add('XΧХ','M70 700L550 0 M550 700L70 0')
add('YΥ','M60 700L310 350L560 700 M310 350V0')
add('ZΖ','M70 700H550L70 0H550')
# Geometric lowercase, including the six logo letters.
add('a','M520 0V500H275C-5 500 -5 0 275 0H520')
add('b','M70 700V0H315C625 0 625 500 315 500H70')
add('cс','M535 450C450 540 70 540 70 250C70 -40 450 -40 535 50')
add('d','M520 700V0H275C-5 0 -5 500 275 500H520')
add('eе','M530 0H280C60 0 65 115 65 250V325C65 425 115 500 245 500H385C575 500 585 300 385 300H185')
add('f','M210 0V565Q210 700 405 700 M60 500H390',460)
add('g','M520 500V-75Q520 -200 330 -200H100 M520 500H275C-5 500 -5 0 275 0H520')
add('h','M70 700V0 M70 365Q70 500 270 500Q520 500 520 310V0')
add('iі','M170 0V500 M170 665V695',340)
add('jј','M285 500V-75Q285 -200 80 -200 M285 665V695',400)
add('k','M70 700V0 M520 500L70 150 M245 285L545 0')
add('l','M160 700V125Q160 0 330 0',400)
add('m','M70 0V500 M70 350Q70 500 225 500Q375 500 375 340V0 M375 350Q375 500 530 500Q685 500 685 340V0',760)
add('n','M70 0V500 M70 355Q70 500 285 500Q525 500 525 315V0')
add('oοо','M310 500C115 500 65 425 65 250C65 75 115 0 310 0C505 0 555 75 555 250C555 425 505 500 310 500Z')
add('pр','M70 -200V500H310C625 500 625 0 310 0H70')
add('q','M520 -200V500H275C-5 500 -5 0 275 0H520')
add('r','M70 0V500 M70 335Q70 500 400 500',470)
add('sѕ','M535 500H190C15 500 15 285 190 285H400C590 285 590 0 400 0H70')
add('t','M145 700V155Q145 0 315 0H480 M145 500H535')
add('u','M70 500V190Q70 0 280 0Q520 0 520 190V500')
add('vν','M60 500L310 0L560 500')
add('w','M50 500L200 0L380 370L560 0L710 500',760)
add('xх','M70 500L550 0 M550 500L70 0')
add('y','M70 500V270Q70 125 270 125H385 M525 500V-25L365 -200H195')
add('z','M70 500H550L70 0H550')
# Cyrillic capitals and lowercase use upright geometric shapes.
add('Б','M550 700H70V0H330C640 0 640 355 330 355H70')
add('ГΓ','M70 0V700H550')
add('Д','M40 -120V0H620V-120 M120 0L210 700H505V0',690)
add('Ж','M380 0V700 M55 700L380 350L55 0 M705 700L380 350L705 0',760)
add('З','M70 650Q180 730 355 700C590 675 600 380 355 355H205 M355 355C640 355 625 -45 335 0Q145 -5 70 65')
add('И','M70 700V0L550 700V0')
add('ЛΛ','M60 0L250 700H510V0')
add('ПΠ','M70 0V700H550V0')
add('У','M60 700L300 230 M560 700L280 0H140')
add('ФΦ','M310 -40V740 M310 600C-25 600 -25 100 310 100C645 100 645 600 310 600Z')
add('Ц','M70 700V0H550V700 M550 0H605V-140',680)
add('Ч','M70 700V470Q70 340 275 340H550 M550 700V0')
add('Ш','M70 700V0H690V700 M380 700V0',760)
add('Щ','M70 700V0H690V700 M380 700V0 M690 0H745V-140',820)
add('Ъ','M30 700H175V0H390C685 0 685 375 390 375H175',680)
add('Ы','M70 700V0H270C570 0 570 375 270 375H70 M655 700V0',730)
add('Ь','M70 700V0H330C650 0 650 375 330 375H70')
add('Э','M70 600C155 745 550 745 550 350C550 -45 155 -45 70 100 M270 350H550')
add('Ю','M70 0V700 M70 350H255 M460 700C275 700 255 550 255 350C255 150 275 0 460 0C645 0 665 150 665 350C665 550 645 700 460 700Z',735)
add('Я','M550 0V700H285C-20 700 -20 355 285 355H550 M285 355L55 0')
for upper,lower in zip('АБВГДЕЖЗИКЛМНПСТУФЦЧШЩЪЫЬЭЮЯ','абвгдежзиклмнпстуфцчшщъыьэюя'):
    if lower not in recipes:
        d,w=recipes[upper]; path=parse_path(d)
        recipes[lower]=(path.scaled(.715,.715).d(),w*.84)
# Greek shapes beyond Latin lookalikes.
add('Δ','M60 0L310 700L560 0Z')
add('Θ','M310 700C90 700 65 570 65 350C65 130 90 0 310 0C530 0 555 130 555 350C555 570 530 700 310 700Z M145 350H475')
add('Ξ','M70 700H550 M140 350H480 M70 0H550')
add('Σ','M550 700H70L350 350L70 0H550')
add('Ψ','M310 0V700 M65 700V390Q65 205 310 205Q555 205 555 390V700')
add('Ω','M70 0H240V100C-15 230 -10 700 310 700C630 700 635 230 380 100V0H550')
add('α','M520 500L385 65Q345 0 235 0C-20 0 -20 500 235 500Q390 500 435 315L550 0')
add('β','M70 -200V545C70 760 520 760 520 545C520 405 340 360 220 360 M220 360C620 360 620 0 290 0H70')
add('γ','M60 500L310 -200 M550 500L310 0')
add('δ','M435 700L215 535C-60 390 20 0 300 0C595 0 620 355 420 520L220 700')
add('ε','M530 440Q390 530 230 500C-5 455 -5 260 220 260H410 M220 260C-15 260 -15 0 250 0Q395 -10 540 65')
add('ζ','M70 700H525L155 155Q70 0 270 0Q510 0 400 -200')
add('η','M70 0V500 M70 355Q70 500 285 500Q525 500 525 315V-200')
add('θ','M310 700C90 700 65 570 65 350C65 130 90 0 310 0C530 0 555 130 555 350C555 570 530 700 310 700Z M65 350H555')
add('ι','M160 500V125Q160 0 330 0',400)
add('κ','M70 0V500 M530 500L70 195 M245 305L545 0')
add('λ','M120 700H240L555 0 M330 465L60 0')
add('μ','M70 -200V500 M70 180Q70 0 275 0Q525 0 525 190V500')
add('ξ','M500 700H275Q65 700 65 545Q65 420 240 420H405 M240 420Q65 420 65 235Q65 80 315 80Q545 80 435 -150')
add('π','M45 500H575 M130 500V0 M500 500V100Q500 0 575 0')
add('ρ','M70 -200V250C70 585 555 585 555 250C555 -85 70 -85 70 250')
add('σ','M575 500H295C-10 500 -10 0 295 0C610 0 590 390 415 485')
add('ς','M520 460C405 560 70 560 70 280Q70 50 310 0Q500 -35 405 -200')
add('τ','M50 500H555 M285 500V120Q285 0 445 0')
add('υ','M70 500V230C70 -80 550 -80 550 230V500')
add('φ','M310 -200V700 M310 500C-25 500 -25 0 310 0C645 0 645 500 310 500Z')
add('χ','M60 500L555 -200 M555 500L60 -200')
add('ψ','M310 -200V700 M65 500V190Q65 0 310 0Q555 0 555 190V500')
add('ω','M80 500C-10 355 20 0 175 0Q310 0 310 270Q310 0 445 0C600 0 630 355 540 500')
add('0','M310 700C90 700 65 570 65 350C65 130 90 0 310 0C530 0 555 130 555 350C555 570 530 700 310 700Z')
add('1','M150 565L330 700V0 M165 0H495')
add('2','M70 535C70 770 550 770 550 535Q550 425 370 290L70 0H550')
add('3','M70 640Q200 750 350 700C625 660 590 350 350 350H235 M350 350C620 350 620 -25 330 0Q170 -20 70 60')
add('4','M455 0V700L65 225H555')
add('5','M550 700H70V370H300C650 370 650 0 300 0H70')
add('6','M535 655C370 785 70 700 70 380V200C70 -70 550 -70 550 200C550 475 70 475 70 200')
add('7','M70 700H550L195 0')
add('8','M310 700C-5 700 -5 355 310 355C625 355 625 700 310 700Z M310 355C-30 355 -30 0 310 0C650 0 650 355 310 355Z')
add('9','M85 45C250 -85 550 0 550 320V500C550 770 70 770 70 500C70 225 550 225 550 500')

def outline(d,circuit,char):
    path=parse_path(d);shapes=[]
    for contour in path.continuous_subpaths():
        pts=[]
        for seg in contour:
            count=max(2,math.ceil(seg.length(error=1e-3)/5))
            pts.extend((seg.point(i/count).real,seg.point(i/count).imag) for i in range(count))
        z=contour[-1].end;pts.append((z.real,z.imag))
        if len(pts)>1:shapes.append(LineString(pts).buffer(37.5,cap_style=2,join_style=1,quad_segs=10))
    geom=unary_union(shapes)
    if circuit:
        if char in 'PРΡ':x,y=70,350
        elif char in 'OОΟoоο0':x,y=555,350 if char.isupper() or char=='0' else 250
        else:z=path[0].start;x,y=z.real,z.imag
        center=Point(x,y);outer=center.buffer(62,quad_segs=24);inner=center.buffer(34,quad_segs=24)
        geom=geom.union(outer).difference(inner)
    return geom.simplify(.6,preserve_topology=True)
def glyph(geom,scale):
    pen=TTGlyphPen(None)
    polys=[geom] if geom.geom_type=='Polygon' else list(geom.geoms)
    for poly in polys:
        poly=orient(poly,sign=-1)
        for ring in [poly.exterior,*poly.interiors]:
            pts=list(ring.coords)[:-1]
            pen.moveTo((round(pts[0][0]*scale),round(pts[0][1]*scale)))
            for x,y in pts[1:]:pen.lineTo((round(x*scale),round(y*scale)))
            pen.closePath()
    return pen.glyph()
def rename(font,family):
    names={1:family,2:'Regular',3:family+' Regular 0.1',4:family+' Regular',5:'Version 0.100',6:family.replace(' ','')+'-Regular',16:family,17:'Regular'}
    for id,val in names.items():
        font['name'].removeNames(nameID=id)
        font['name'].setName(val,id,3,1,0x409);font['name'].setName(val,id,1,0,0)
    font['name'].setName('Geometric PsyNet derivatives; extended coverage based on DejaVu Sans. See LICENSE.txt.',10,3,1,0x409)
def make(circuit):
    family='PsyNet Circuit' if circuit else 'PsyNet Sans'
    font=TTFont('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf');cmap=font.getBestCmap();scale=font['head'].unitsPerEm/1000
    for c,(d,w) in recipes.items():
        name=cmap.get(ord(c))
        if name:
            gl=glyph(outline(d,circuit,c),scale);font['glyf'][name]=gl
            gl.recalcBounds(font['glyf']);font['hmtx'][name]=(round((w+30)*scale),gl.xMin)
    # Modified bases also feed existing precomposed accents and combining marks.
    for tag in ['GSUB','GPOS','kern','DSIG']:
        if tag in font:del font[tag]
    rename(font,family);font['OS/2'].sTypoAscender=round(900*scale);font['OS/2'].sTypoDescender=round(-270*scale);font['OS/2'].sTypoLineGap=0
    font['hhea'].ascent=round(1050*scale);font['hhea'].descent=round(-350*scale)
    font['OS/2'].usWinAscent=round(1200*scale);font['OS/2'].usWinDescent=round(450*scale)
    font['OS/2'].fsType=0
    stem=family.replace(' ','-')+'-Regular';font.save(OUT/(stem+'.ttf'))
    # A native CFF OpenType companion, not merely a renamed TTF file.
    gs=font.getGlyphSet();order=font.getGlyphOrder();charstrings={}
    for name in order:
        pen=T2CharStringPen(font['hmtx'][name][0],gs);gs[name].draw(pen);charstrings[name]=pen.getCharString()
    fb=FontBuilder(font['head'].unitsPerEm,isTTF=False);fb.setupGlyphOrder(order);fb.setupCharacterMap(cmap)
    fb.setupHorizontalMetrics(font['hmtx'].metrics);fb.setupHorizontalHeader(ascent=font['hhea'].ascent,descent=font['hhea'].descent)
    fb.setupNameTable({'familyName':family,'styleName':'Regular','uniqueFontIdentifier':family+' Regular 0.1 CFF','fullName':family+' Regular','psName':family.replace(' ','')+'-Regular','version':'Version 0.100'})
    fb.setupOS2(sTypoAscender=font['OS/2'].sTypoAscender,sTypoDescender=font['OS/2'].sTypoDescender,usWinAscent=font['OS/2'].usWinAscent,usWinDescent=font['OS/2'].usWinDescent,fsType=0)
    fb.setupPost();fb.setupCFF(family.replace(' ','')+'-Regular',{'FullName':family+' Regular','FamilyName':family,'Weight':'Regular'},charstrings,{})
    fb.save(OUT/(stem+'.otf'));return family
for circuit in [False,True]:print('Built:',make(circuit),flush=True)
license=Path('/usr/share/doc/fonts-dejavu-core/copyright').read_text().split('Files: debian/*')[0]
(OUT/'LICENSE.txt').write_text(license+'\nPsyNet custom glyph modifications: free use, modification and redistribution under the above font license.\n')
(OUT/'README.txt').write_text('PsyNet Fonts — version 0.1\n\nPsyNet Sans: geometric alphabet for regular text.\nPsyNet Circuit: display alphabet with contact rings.\n\nInstall either TTF or OTF, not both formats of the same family.\nLatin, Cyrillic and Greek, digits, punctuation and combining accents are included.\nPrimary alphabet glyphs are redrawn; extended characters and accent positioning are derived from DejaVu Sans.\nThis is a first design release; no bold or italic styles or custom kerning yet.\nCircuit is intended for headings, not small body text.\n\nLicense: see LICENSE.txt.\n')
samples=['PsyNet — Genesis 2026','ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz','АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ','абвгдеёжзийклмнопрстуфхцчшщъыьэюя','ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ','αβγδεζηθικλμνξοπρστυφχψω','Ελληνικά — Κύπρος — Ψυχή','0123456789 !? @ # & + − =']
im=Image.new('RGB',(1800,1600),'#090b13');dr=ImageDraw.Draw(im)
for j,stem in enumerate(['PsyNet-Sans-Regular','PsyNet-Circuit-Regular']):
    y=40+j*800
    titlefont=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',30);dr.text((55,y),stem,fill='#94eceb',font=titlefont)
    for i,line in enumerate(samples):
        f=ImageFont.truetype(str(OUT/(stem+'.ttf')),45 if i else 74)
        dr.text((55,y+65+i*72),line,fill='#ece6ff',font=f)
im.save(P/'font-specimen.png');im.save(OUT/'Specimen.png')
html='''<!doctype html><meta charset="utf-8"><title>PsyNet Font Specimen</title><style>@font-face{font-family:PsyNet;src:url(PsyNet-Sans-Regular.ttf)}@font-face{font-family:Circuit;src:url(PsyNet-Circuit-Regular.ttf)}body{background:#090b13;color:#eee;padding:40px}section{font-size:36px;line-height:1.8}.sans{font-family:PsyNet}.circuit{font-family:Circuit}h1{font:24px sans-serif;color:turquoise}</style>'''
for family,cls in [('PsyNet Sans','sans'),('PsyNet Circuit','circuit')]:html+='<h1>'+family+'</h1><section class="'+cls+'" contenteditable="true">'+'<br>'.join(samples)+'</section>'
(OUT/'Specimen.html').write_text(html)
# Verify character coverage and valid glyph outlines in every delivered font.
required='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюяΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψωάέήίόύώϊϋΐΰς0123456789'
for path in sorted(OUT.glob('*tf')):
    f=TTFont(path);missing=[c for c in required if ord(c) not in f.getBestCmap()];assert not missing,(path,missing)
    print('Verified:',path.name,len(f.getBestCmap()),'mapped characters',flush=True)
with zipfile.ZipFile(P/'PsyNet-Fonts.zip','w',zipfile.ZIP_DEFLATED) as z:
    for file in sorted(OUT.iterdir()):z.write(file,'PsyNet-Fonts/'+file.name)
print('Package ready:',P/'PsyNet-Fonts.zip')
